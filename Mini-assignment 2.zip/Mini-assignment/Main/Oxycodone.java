package Main;
public class Oxycodone extends Medicine {

    public Oxycodone() {
        super("Oxycodone");
    }

    @Override
    public MedicineSchedule getSchedule() {
        return MedicineSchedule.Two;
    }

    @Override
    public double minimumTemperature() {
        // Specify the minimum safe temperature for Oxycodone
        return 30.0;
    }

    @Override
    public double maximumTemperature() {
        // Specify the maximum safe temperature for Oxycodone
        return 90.0;
    }

    @Override
    public boolean isTemperatureRangeAcceptable(Double lowTemperature, Double highTemperature) {
        return this.minimumTemperature() <= lowTemperature && highTemperature <= this.maximumTemperature();
    }
}
