package Main;
public class Ibuprofen extends Medicine {

    public Ibuprofen() {
        super("Ibuprofen");
    }

    @Override
    public MedicineSchedule getSchedule() {
        return MedicineSchedule.Uncontrolled;
    }

    @Override
    public double minimumTemperature() {
        return 30.0;
    }

    @Override
    public double maximumTemperature() {
        return 90.0;
    }

    @Override
    public boolean isTemperatureRangeAcceptable(Double lowTemperature, Double highTemperature) {
        return this.minimumTemperature() <= lowTemperature && highTemperature <= this.maximumTemperature();
    }
}

