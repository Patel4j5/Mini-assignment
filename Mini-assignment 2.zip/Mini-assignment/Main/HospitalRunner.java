package Main;

public class HospitalRunner {
    public static void run() {
        // Create a transporter with a name and temperature range that is more suitable for volatile medicines
        Transporter priorityDispatch = new Transporter("Priority Dispatch", 40.0, 41.0);

        // Create a pharmacy
        Pharmacy cvs = new Pharmacy("CVS at 7500 Beechmont Avenue");

        // Direct the pharmacy to send its medicine using the better transporter
        cvs.send(priorityDispatch);

        // Create a hospital
        Hospital uc = new Hospital("World Famous University of Cincinnati Children's Hospital");

        // Direct the hospital to receive the shipment from the better transporter
        uc.receive(priorityDispatch);
    }
}


