package Main;
public abstract class Medicine implements Shippable {
    private String mMedicineName;

    public Medicine(String medicineName) {
        mMedicineName = medicineName;
    }

    @Override
    public String getMedicineName() {
        return mMedicineName;
    }

    @Override
    public abstract MedicineSchedule getSchedule();

    public abstract double minimumTemperature();

    public abstract double maximumTemperature();

    @Override
    public boolean isTemperatureRangeAcceptable(Double lowTemperature, Double highTemperature) {
        return this.minimumTemperature() <= lowTemperature && highTemperature <= this.maximumTemperature();
    }
}


