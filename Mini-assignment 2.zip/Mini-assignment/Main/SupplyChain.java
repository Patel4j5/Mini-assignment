package Main;
public class SupplyChain {
    public static void main(String[] args) {
        // Run the hospital simulation
        HospitalRunner.run();
    }
}
