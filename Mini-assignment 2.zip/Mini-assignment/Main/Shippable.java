package Main;
public interface Shippable {
    MedicineSchedule getSchedule();
    String getMedicineName();
    boolean isTemperatureRangeAcceptable(Double lowTemperature, Double highTemperature);
}

